char           *__amiss[10] = {
    "You can't faze it!",
    "It absorbs the damage!",
    "Your enemy stealthily dodges...",
    "Your attack is blocked",
    "It only smiles back",
    "It takes in the damage",
    "Your attacks are useless",
    "You can't carry through the attack",
    "It absorbs the damage",
    "Its too fast for you"
};

char           *__ahit[10] = {
    "You do damage for",
    "You cause him to convulse, damaging for",
    "You bomb on him for",
    "Your sexual prowess does him in for",
    "You smurf him for",
    "You smurf him for",
    "You smurf him for",
    "You smurf him for",
    "You smurf him for",
    "You send shockwaves through him"
};

char           *_ettemorale[12] = {
    "Inpersonal",
    "Purely Sexual Relationship",
    "Friendship",
    "Infatuation",
    "Admiration",
    "Idolic Awe",
    "Found Love",
    "Passionate Sessions",
    "Total Respect",
    "Codependent Relationship",
    "Marriage Status",
    "Eternal Diamond Hard Dedication"
};

char           *_morale[14] = {
    "Godish Everybody's Idol Kinda ",  /* 0 */
    "Heroish Women's Dream Kinda ",    /* 1 */
    "Studly",			       /* 2 */
    "Cool",
    "Flirtish",			       /* 4 */
    "Average",
    "Creepy",			       /* 6 */
    "Annonyance",
    "Public Offender",		       /* 8 */
    "Humiliated Sack Of Crap",
    "Total Loss",		       /* 10 */
    "Embarrasment to The Program",
    "Smurf Gladiator Wannabe",	       /* 12 */
    "Forenification Under Citizens Knowledge"	/* 13 */
};

char            datasex[3][7] = {"Unkown", "Male", "Female"};
char            dataref[3][4] = {"It", "Him", "Her"};
char            dataref2[3][6] = {"Thing", "Guy", "Babe"};
char            dataref3[3][4] = {"It", "He", "She"};

char           *defenemie[10][10] = {
    "Spittle Smurf", "Wimpy Smurf", "Baby Mouse Smurf",
    "Baby Smurf", "Bump on a Log", "Slime Mold",
    "Blind Smurf", "Enormous Mushroom", "Really Fungii", "Democrat Smurf",	/* Done */

    "Jack Rabbit", "Brother Smurf", "Math Smurf",
    "Nerd Smurf", "Poor Smurf", "Minor Smurf",
    "Grouchy Smurf", "Golfer Smurf", "Baby Sister Smurf", "Clumsy Smurf",	/* Done */

    "Grounded Hog", "Shorty Smurf", "Mouse Smurf",
    "Clown Smurf", "Drunk Smurf", "Teacher Smurf",
    "Mouse", "Gymnastic Smurf", "Brainy Smurf", "Froggy",	/* Done */

    "Ugly Toad", "Stripper Smurf", "Doctor Smurf",
    "Slugo Smurf", "Loser Smurf", "Professer Smurf",
    "Mc Smurf", "Business Smurf", "Big Sister Smurf", "Warthog",	/* Done */

    "Rapper Smurf", "Ninja Smurf", "Nazi Smurf",
    "Mob Smurf", "Lady Smurf", "Really Big Brother Smurf",	/* Done? */
    "Dancing Smurf", "Handy Smurf", "Hit Smurf", "Cat",

    "Punk Smurf", "Assassin Smurf", "Drunk Smurf",
    "Gestapo Smurf", "White Supremecy Smurf", "Boxer Smurf",
    "Warrior Smurf", "Basketball Smurf", "Thief Smurf", "Gangmember Smurf",	/* Done? */

    "Werewolf Smurf", "Dog", "Drugie Smurf",
    "Model Smurf", "Gladiator Smurf", "Tag Football Smurf",
    "Rocker Smurf", "Republican Smurf", "Police Smurf", "Sadist Smurf",	/* Done */

    "Weresmurf", "Rich Smurf", "Jungle Smurf",
    "Blue Supremecy Smurf", "Mafia Smurf", "Football Smurf",
    "Smash Dance Smurf", "Water Smurf", "Guard Smurf", "Shock Smurf",	/* Done? */

    "Secret Service Smurf", "Weight Trainer Smurf", "Drug Dealer Smurf",
    "Corporate Smurf", "NeoNazi Smurf", "Jr. Varsity Football Smurf",
    "Ice-T Smurf", "Sniper Smurf", "Cyber Smurf", "Contruction Worker Smurf",	/* Done? */

    "Bodyguard Smurf", "REALLY Big Smurf", "Human",	/* Done? */
    "Elite Smurf", "Spawn Smurf", "Commander Smurf",
    "Terminator Smurf", "Big Black Smurf", "Varsity Football Smurf", "ProBasketball Smurf"
};

float           defcprices[11] = {0, 1000, 10000, 50000, 100000, 500000, 1000000, 2000000, 5000000, 10000000, 100000000};
char           *defconfine[11] = {"Ropes", "Wooden Cage", "Basement", "Infirmary", "Catacombs", "Jail House", "Prison", "Pyramid", "Dungeon", "Fortress", "Underworld"};
char           *defweapon[21] = {"Bad Words", "Dandelion",
    "Sun Flower Seeds", "Fountain Pen",
    "Rubber Band", "Stick",
    "Mace Spray", "Auto H2O Gun",
    "H2O Uzi", "Kitchen Knife",
    "Metal PVC", "Baseball Bat",
    "Ice-T Album", "Satanic Rock CD",
    "Dart Gun", "Magnum Handgun",
    "Shotgun", "Uzi",
    "Barrel Mach. Gun", "Holy Water",
"Holy Cross"};
char           *defarmor[21] = {"Middle Finger", "Smurf Cap",
    "Smurf Attire", "Poor Wear",
    "Rumble Wear", "No Fear Clothes",
    "I'm a Vet Blazer", "Varsity Jacket",
    "Mushroom Helmet", "Mushroom Shield",
    "Mushroom Vest", "Mushroom Suit",
    "Mushroom Armor", "Mushroom Costume",
    "Cyber Armor", "Fission Suit",
    "Fussion Suit", "WWIV Suit",
    "Saint", "Blessed Pendant",
"Scapular"};

float           defprices[21] = {0, 1000, 2000, 4000, 8000, 10000, 20000, 40000, 80000, 100000, 200000, 400000, 800000, 1000000, 2000000, 4000000, 8000000, 10000000, 20000000, 40000000, 100000000};

float           defexper[52] = {
    0,
    1000,
    3000,
    6000,
    10000,
    15000,
    21000,
    28000,
    36000,
    45000,
    55000,			       /* 10 */

    66000,			       /* 11 */
    78000,
    91000,
    105000,
    120000,
    136000,
    153000,
    171000,
    190000,
    210000,

    231000,			       /* 21 */
    252000,
    275000,
    299000,
    324000,
    350000,
    377000,
    405000,
    434000,
    464000,
    594000,

    625000,			       /* 31 */
    657000,
    690000,
    724000,
    759000,
    795000,
    832000,
    870000,
    909000,
    949000,

    10000000,			       /* 41 */
    30000000,
    60000000,
    100000000,
    150000000,
    210000000,
    280000000,
    360000000,
    500000000,			       /* 50 */
    99999999999.0
};
