char            __NEW__smurfname[10][41] = {"GRANDPA SMURF", "PAPA SMURF", "SHADOW SMURF", "REBEL SMURF"};
char            __NEW__realname[10][41] = {"GRANDPA SMURF", "PAPA SMURF", "SHADOW SMURF", "REBEL SMURF"};
int             __NEW__realnumb[10] = {0, 0, 0, 0};
char            __NEW__smurfweap[10][41] = {"Burning Cross", "Fire Water", "Shadow Lance", "H2O Uzi"};
char            __NEW__smurfarmr[10][41] = {"Inverted Star", "Armor", "Shadow Shield", "No Fear Clothes"};
char            __NEW__smurftext[10][81] = {"The forces of evil will prevail!",
    "Didn't anyone teach you to respect your dad!?!?",
    "Fool, now the S.S. must make you pay . . .",
"Traitor! You are one of PAPA SMURF'S henchmen!"};

char            __NEW__smurfettename[10][41] = {"Female Fetale", "Fire Eyes", "Shadow Girl", "Cassie"};
int             __NEW__smurfettelevel[10] = {10, 9, 7, 5};

int             __NEW__smurfweapno[10] = {20, 19, 3, 8};
int             __NEW__smurfarmrno[10] = {20, 19, 3, 8};

char            __NEW__smurfconf[10][41] = {"Underworld", "Fortress", "Basement", "Infirmary"};
int             __NEW__smurfconfno[10] = {11, 10, 2, 3};

int             __NEW__smurfhost[10][10] = {255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255};

int             __NEW__smurflevel[10] = {41, 30, 3, 3};
float           __NEW__smurfmoney[10] = {8458, 3245, 3491, 745};
float           __NEW__smurfbankd[10] = {927231, 78735, 5497, 2446};
float           __NEW__smurfexper[10] = {10000000, 594000, 4000, 3000};
int             __NEW__smurffights[10] = {3, 3, 3, 0};
int             __NEW__smurfwin[10] = {231, 117, 23, 34};
int             __NEW__smurflose[10] = {0, 1, 3, 2};
int             __NEW__smurfhp[10] = {413, 329, 36, 34};
int             __NEW__smurfhpm[10] = {413, 329, 36, 34};
int             __NEW__smurfstr[10] = {42, 37, 12, 16};
int             __NEW__smurfspd[10] = {45, 32, 22, 13};
int             __NEW__smurfint[10] = {26, 23, 13, 11};
int             __NEW__smurfcon[10] = {31, 24, 14, 12};
int             __NEW__smurfbra[10] = {36, 42, 12, 12};
int             __NEW__smurfchr[10] = {13, 27, 8, 17};
int             __NEW__smurfturns[10] = {3, 3, 3, 3};
int             __NEW__smurfspcweapon[10][6] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
int             __NEW__smurfqtyweapon[10][6] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
char            __NEW__smurfsex[10] = {1, 1, 1, 1, 1, 1, 1, 1, 1, 1};
int             __NEW____morale[41] = {0, 1, 2, 2};
int             __NEW____ettemorale[41] = {752, 512, 213, 198};
