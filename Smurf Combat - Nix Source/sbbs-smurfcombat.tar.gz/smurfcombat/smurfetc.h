int             thishostcount = 0;
void            detectsave(void);
