#ifndef _INC_MDEL_H_
#define _INC_MDEL_H_

#if defined(__cplusplus)
extern          "C" {
#endif
    int             mdel(char *pattern);
#if defined(__cplusplus)
}
#endif

#endif
