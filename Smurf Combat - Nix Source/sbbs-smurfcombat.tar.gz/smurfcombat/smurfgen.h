#include<datewrap.h>
struct date     d;
int             timeoud = 0, tcount = 0;
char            intext[81], olddate[10];
char            proc;
